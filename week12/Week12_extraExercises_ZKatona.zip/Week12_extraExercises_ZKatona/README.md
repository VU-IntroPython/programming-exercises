# Extra exercises Week 12
(Made by: Zsófia Katona)

-----

This project consists of two .py files: `geometry.py`, which contains the `RightTriangle` class, and `perimeterCalculator.py`, which is a simple interactive program to calculate the perimeter of a right triangle.

-----

## Task 1

Your first task is to add a method called `hypotenuse` to the `RightTriangle` class, which returns the length of the triangle's hypotenuse as a float. \
\
*Notes:*

* To calculate the length of the hypotenuse, it is easiest to use the Pythagoras Theorem.
* To use the Theorem, you will need to calculate a square root. For this purpose, the `math` module's `sqrt` function has been imported in `geometry.py`.
* Do not forget to add type hints and a docstring.

-----

## Task 2

Finish the perimeter calculator program in `perimeterCalculator.py`.

*Notes:*

* The program should make use of the `RightTriangle` class and the `hypotenuse` method. Pay attention that you will have to import these at the beginning of the script.
* The program should print a message with the length of the perimeter rounded to 2 decimals.

*Example:*

Input:

`Please give the length of the first leg of the triangle:3` \
`Please give the length of the second leg of the triangle:4`

Output:

`The triangle has a perimeter of 12.00 units.`
