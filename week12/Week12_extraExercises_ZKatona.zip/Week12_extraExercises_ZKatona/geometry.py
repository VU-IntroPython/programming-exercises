from math import sqrt

class RightTriangle():
    '''
    Represents right triangles with the length of the two legs "a" and "b" given as attributes.
    '''

    def __init__(self, a: float, b: float) -> None:
        self.a = a
        self.b = b

#### Begin the hypotenuse method AFTER this line.

# Example solution:
    def hypotenuse(self) -> float:
        '''
        This function calculates the length of the hypotenuse in the triangle.
        :return: a float representing the length of the hypotenuse.
        '''

        return sqrt(self.a ** 2 + self.b ** 2)

#### Finish the hypotenuse method BEFORE this line.





