#### Begin importing AFTER this line.

# Example solution:
from geometry import RightTriangle

#### Finish importing BEFORE this line.

print('''
Welcome to the triangle perimeter calculator!
Please note that the calculator only works on right triangles.
''')

a = float(input("Please give the length of the first leg of the triangle:"))
b = float(input("Please give the length of the second leg of the triangle:"))

print('')

#### Begin implementing perimeter calculation AFTER this line.

# Example solution:
triangle = RightTriangle(a, b)

c = triangle.hypotenuse()

perimeter = a + b + c

print('The triangle has a perimeter of {pm:.2f} units.'.format(pm=perimeter))

#### Finish implementing perimeter calculation BEFORE this line.

